/** @type {import('next').NextConfig} */
const nextConfig = {
    output: undefined, // Keep SSR enabled
  };
  
  module.exports = nextConfig;